package com.EcfBack.Oussama.m2i.Locataires;

public class LocataireServiceImplementation {
    public LocataireServiceImplementation(LocataireRepository locataireRepository) {
    }
}
