package com.EcfBack.Oussama.m2i.Vehicules;

public enum EtatVehicules {

    S,A,L,U,T;


}
