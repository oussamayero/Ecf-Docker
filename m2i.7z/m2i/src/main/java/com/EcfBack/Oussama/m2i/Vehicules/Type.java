package com.EcfBack.Oussama.m2i.Vehicules;

public enum Type {
    Camion,Voiture,Moto;
}
