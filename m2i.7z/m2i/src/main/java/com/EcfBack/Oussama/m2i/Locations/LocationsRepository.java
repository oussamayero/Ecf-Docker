package com.EcfBack.Oussama.m2i.Locations;

public interface LocationsRepository {
}
