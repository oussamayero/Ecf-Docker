package com.EcfBack.Oussama.m2i.Vehicules;

public class VehiculesServiceImplementation {
    public VehiculesServiceImplementation(VehiculesRepository vehiculeRepository) {
    }
}
