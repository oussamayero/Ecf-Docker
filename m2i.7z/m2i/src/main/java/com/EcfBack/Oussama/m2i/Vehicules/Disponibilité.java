package com.EcfBack.Oussama.m2i.Vehicules;

public enum Disponibilité {

    Disponible,Indisponible;
}
